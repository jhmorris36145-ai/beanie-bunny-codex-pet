Create one clean full-body reference sprite for ChatGPT pet Beanie Bunny.

Pet identity: User supplied 2048x1152 reference image: compact white fluffy rabbit, tall white ears with pink interiors, black ribbed knit beanie, dark gray large eyes, pink nose, stern brows, short round body, tiny round tail. Preserve identity and face. Plush 3D toy look. Public GitHub sharing project..
Style: Pet-safe sprite: compact full-body mascot, readable in a 192x208 cell, clear silhouette, simple face, stable palette/materials, and crisp edges for chroma-key extraction. Style `plush`: Soft plush toy mascot with rounded stitched forms, fuzzy fabric feel, simple sewn details, and readable toy-like proportions.


Place a single centered pose on a perfectly flat pure magenta #FF00FF chroma-key background. Keep the full pet visible, compact, readable at 192x208, and easy to animate. Preserve approved reference identity cues. No scenery, text, borders, checkerboard transparency, shadows, glows, detached effects, or extra props. Keep #FF00FF and close colors out of the pet, props, highlights, and effects.
